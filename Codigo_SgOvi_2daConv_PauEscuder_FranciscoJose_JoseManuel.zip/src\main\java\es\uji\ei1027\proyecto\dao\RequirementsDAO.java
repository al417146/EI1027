package es.uji.ei1027.proyecto.dao;

import es.uji.ei1027.proyecto.RowMaps.RequirementsRowMapper;
import es.uji.ei1027.proyecto.modelo.Requirements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

@Repository
public class RequirementsDAO {
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public void setDataSource(DataSource dataSource){
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public void addRequirement(Requirements r){
        jdbcTemplate.update("INSERT INTO Requirements VALUES (?,?,?)",
                r.getIdRequirement(),
                r.getTopic(),
                r.getDesc());
    }

    public void deleteRequirement(int idRequirement){
        jdbcTemplate.update("DELETE FROM requirement WHERE idRequirement=?",
                idRequirement);
    }

    public void updateRequirement(Requirements r){
        jdbcTemplate.update("UPDATE Requirements SET topic=?, desc=? WHERE idRequirement=?",
                r.getTopic(),
                r.getDesc(),
                r.getIdRequirement());
    }

    public Requirements getRequirement(int id){
        try{
            return jdbcTemplate.queryForObject(
                    "SELECT * FROM requirement WHERE idRequirement=?",
                    new RequirementsRowMapper(),
                    id);
        } catch(EmptyResultDataAccessException e){
            return null;
        }
    }

    public List<Requirements> getRequirements(){
        try{
            return jdbcTemplate.query("SELECT * FROM requirement",
                    new RequirementsRowMapper());
        } catch(EmptyResultDataAccessException e){
            return new ArrayList<>();
        }
    }
}